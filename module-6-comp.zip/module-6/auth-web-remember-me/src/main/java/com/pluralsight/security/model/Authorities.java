package com.pluralsight.security.model;

public interface Authorities {

	static final String TOTP_AUTH_AUTHORITY = "TOTP_AUTH_AUTHORITY";
	static final String ROLE_USER = "ROLE_USER";
	
}
