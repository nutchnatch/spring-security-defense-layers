To run this demo, you will need to add your google and facebook keys to the application.yml file.
See module 7 clip 2 Sign-in with Google or Facebook 