package com.pluralsight.security.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TotpCode {

	private String code;
	
}
