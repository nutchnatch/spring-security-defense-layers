Users: (username / password)
snakamoto / bitcoin
user / password