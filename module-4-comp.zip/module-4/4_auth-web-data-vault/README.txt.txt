You will need to register a new user to login to the site:
http://localhost:8080/register

You need to install and setup Vault for this demo to run, watch module 4 clip 7 Securing Secrets with Spring Cloud Vault 
